![Logo UCN](60x60-ucn-negro.png)
# Laboratorio 03: Histograma y gráfico de caja y bigote sobre velocidades

**Alumnos:** Juan Pinilla, Ignacio Garín

**Docentes:** Juan Bekios, Diego Valdivia

**Ayudante:** Cristian Galleguillos 

## 1. Introducción 

**Definición del problema** (600 caracteres máximo)

Dado un conjunto de archivos de texto que contienen coordenadas de peatones mientras transitan por un pasillo con puertas de diferentes medidas, se requiere la creación de un gráfico del tipo histograma que permita discernir la distribución de las velocidades, y además, un gráfico boxplot que permita visualizar la variación las velocidades. Además obtenga estadísticos útiles, como promedio, valor mínimo, valor máximo, entre otros.

Por último, realice una comparación estadística en función del ancho de las puertas.

### 1.1 Justificación (500 caracteres máximo)

Para poder decidir cuál podría ser un buen ancho de puertas, se tiene que considerar las velocidades en la que circulan los peatones (una velocidad alta, podría entenderse como un mayor camino más expedito, lo cual podría ser positivo) junto con su varianza, desviación, media, mínimo, máximo, entre otros. Es por ello que para poder visualizar y comprender de mejor manera la variable velocidad, se debe generar gráficos histogramas y boxplot.

### 1.2 Objetivos 

**Objetivo General**

Realizar un análisis a las velocidades de los peatones según el ancho de las puertas, mediantes gráficos y estadísticos relevantes.

**Objetivos específicos**

1. Obtener las velocidades promedio por peatón.

2. Generar gráfico de histograma y boxplot en donde la variable de interés sea la velocidad para cada medida de ancho de puertas y peatón.

3. Analizar los gráficos obtenidos en su respectivo contexto.

4. Establecer comparativa entre resultados dependiendo de las medidas de las puertas.

## 2. Marco teórico (800 caracteres)

**Python**: Lenguaje de programación de alto nivel, ampliamente utilizado.

**Visual Studio**: Editor de código fuente altamente popular, desarrollado por Microsoft. Es una herramienta de programación de código abierto que admite múltiples lenguajes de programación y proporciona una amplia gama de características útiles.

**Librerías utilizadas**:
- Pandas: Librería de Python especializada en el manejo y análisis de estructuras de datos.
- NumPy: Biblioteca para cálculos numéricos y manipulación de arreglos multidimensionales.
- Matplotlib: Biblioteca para crear gráficos y visualizaciones de datos en diversas dimensiones.
- Random: Librería para generar valores aleatorios, entre otros.

## 3. Materiales y métodos

Se usaron dos datasets de nombres "UNI_CORR_500_01" y "UNI_CORR_500_06". Los archivos de texto tienen 5 columnas y más de 25.000 filas. Describen la ubicación de las personas usando sus coordenadas en diferentes frames. Las posiciones están en metros. La diferencia entre ambos es la longitud de las puertas, teniendo el primero entradas de 1 y 5 metros, y el segundo de 5 y 4 metros. La cámara captó imágenes a 25 fps.

El experimento busca analizar las velocidades de los peatones a través de corredores con diferentes entradas, mediante métricas y gráficas.

En física, la velocidad se expresa como la distancia divida en el tiempo. En este caso el tiempo es equivalente a la diferencia entre un frame y otro, divido por los fps, y ya que todos los frames son consecutivos, el resultado es 1/25 (seg/frame). Para calcular la distancia, se usará la fórmula euclidiana de distancia entre dos puntos consecutivos a partir de sus coordenadas X e Y.

En python, primero se capturó la información en un dataframe como ya se ha hecho anteriormente. Para calcular la resta entre una coordenada y la siguiente se usa la función "diff", y se le entrega el parámetro -1. En consecuencia, esto hará que el último frame no tenga siguiente y la resta entregue un NaN, pero al ser solo un dato se desprecia. Esta resta se aplica para todos los datos de la columna X y la columna Y, luego se elevan al cuadrado, se suman y se aplica raíz, resultando así la distancia recorrida por un peatón entre un frame y otro. La columna resultado se divide por la constante de tiempo y entrega las velocidades por cada frame.

Para facilitar el estudio de los datos se calcula la velocidad promedio, agrupando por cada peatón. Mencionar que hay un control de outliers, pues la función diff al llegar al último frame de cada peatón restará con el primero del siguiente peatón, devolviendo una distancia muy alta (uno viene saliendo y el otro entrando).

Para la creación del histograma se entrega como único parámetro la columna con las velocidades promedio. Para los gráficos de caja y bigote se escoge una muestra de cuatro peatones al azar y se guarda la columna con sus velocidades en una lista. Finalmente, el código está contenido en una función que recibe como parámetro archivos de texto, para así establecer comparativas.

## 4. Resultados obtenidos

La ejecución del algoritmo permite visualizar el comportamiento de las velocidades de los peatones con histogramas y gráficos de caja y bigote además de métricas estadísticas.

![Velocidades de la muestra 1](velocidad1.png)

![Velocidades de la muestra 6](velocidad6.png)

Para el primer caso donde se tienen entradas de 1 y 5 metros, la velocidad se comporta similar a una distribución normal, oscilando entre 0.9 y 2.5 metros/seg. En el segundo caso, con entradas de 5 y 4 metros se observa una menor velocidad promedio y un gráfico sesgado hacia la izquierda. Ambas muestran tienen poca varianza lo cual tiene lógica pues en general las personas caminan al mismo ritmo. La relación entre estos resultados tiene mucho sentido y va ligado con el laboratorio anterior donde se aclaró que si bien aumentar el diámetro de las entradas aumenta la densidad de personas en el pasillo y el uso de los recursos, sería inverso a la velocidad con que caminan los peatones, similar al comportamiento de una feria, donde hay una gran masa de personas pero se ven obligadas a caminar despacio para no atropellarse unos con otros. Esto implicaría un mayor tiempo de circulación, podría ser beneficioso para la incorporación de publicidad pero generaría inconformidad entre los peatones, o también, si el objetivo fuera disminuir el tiempo de uso de los recursos, esta no sería la solución.

![Caja y bigote muestra 1](cajaybigote1.png)

![Caja y bigote muestra 6](cajaybigote6.png)

Los gráficos de caja y bigote de una muestra de 4 peatones fueron clave para ratificar las estadísticas obtenidas previamente, permitiendo visualizar los outliers que antes pasaban por alto.

## 5. Conclusiones

Luego de realizar el laboratorio se pudieron visualizar histogramas y gráficas de caja y bigote para las velocidades promedio de los peatones.

Sobre el desarrollo, este laboratorio sirvió para aplicar y adquirir conocimientos de todas las librerías usadas, como funciones de agregado, filtros y gráficos múltiples aleatorios.

Sobre los resultados, los cálculos de velocidad son coherentes con los datos de entrada y el contexto, además que fueron ratificados tanto con las gráficas como con los estadísticos. Se puede concluir que el tener entradas más amplias aumenta el flujo y la densidad de personas en el corredor pero esto a la vez disminuye la velocidad con la que transitan los peatones, manteniendo el sistema en constante uso, lo cual puede ser positivo o negativo dependiendo de cual sea la finalidad del pasillo.

Los conocimientos adquiridos y reforzados serán de utilidad en la vida profesional, pues un ingeniero debe ser capaz de representar fielmente un sistema y poder concluir en base a el.