#!/usr/bin/env python
# coding: utf-8

# In[21]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random

def programa(archivo,numero):
    print("---------------------------------------------------------------------------------------------------")
    print("Muestra número",numero)
    print()
    
    dataFrame = pd.read_csv(archivo,delimiter="\t",skiprows=3)
    tiempo = 1/25 #fps por segundo
    
    #crear columna de distancia entre coordenadas de un frame a otro
    dataFrame["Distancia"] = (dataFrame["X"].diff(periods=-1)**2 + dataFrame["Y"].diff(periods=-1)**2)**0.5 
    dataFrame["Velocidad"] = dataFrame["Distancia"]/tiempo
    dataFrame = dataFrame[dataFrame["Velocidad"]<10] #control de outliers
    dataFramePromedio = dataFrame.groupby("# PersID")["Velocidad"].mean()

    print("Promedio de las velocidades:",round((dataFramePromedio).mean(),2),"mts/seg")
    print("Varianza de las velocidades:",round((dataFramePromedio).var(),2),"mts/seg")
    print("Mínima velocidad registrada:",round(min(dataFramePromedio),2),"mts/seg")
    print("Máxima velocidad registrada:",round(max(dataFramePromedio),2),"mts/seg")

    #Crear histograma
    plt.hist(dataFramePromedio, bins=25, edgecolor='black')
    plt.xlabel('Velocidades (mts/seg)')
    plt.ylabel('Frecuencia')
    plt.title('Histograma de velocidades')
    plt.show()
    
    #Diagrama de cajas y bigotes
    
    listaMatrices = []
    for i in range(4):
        persona_aleatoria = random.randint(1,148)
        valor_condicional = dataFrame.loc[dataFrame['# PersID'] == persona_aleatoria]
        ultimo_indice = valor_condicional.index[-1]
        valor_condicional_modificado = valor_condicional.drop(ultimo_indice)
        listaMatrices.append(valor_condicional_modificado["Velocidad"])
        
    fig, ax = plt.subplots(2, 2, sharey=True)
    ax[0, 0].boxplot(listaMatrices[0])
    ax[0, 1].boxplot(listaMatrices[1])
    ax[1, 0].boxplot(listaMatrices[2])
    ax[1, 1].boxplot(listaMatrices[3])
    
    ax[0,0].set_ylabel("Velocidad (m/s)")
    ax[1,0].set_ylabel("Velocidad (m/s)")
    plt.show()

programa("UNI_CORR_500_01.txt",1)
programa("UNI_CORR_500_06.txt",6)


# In[ ]:




